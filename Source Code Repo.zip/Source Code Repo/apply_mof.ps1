Start-DscConfiguration -Path '.\ApplyWindowsServerStig' -Wait -Verbose -ComputerName 'localhost' -Force
