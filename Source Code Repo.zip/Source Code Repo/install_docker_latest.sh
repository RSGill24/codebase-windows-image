sudo DEBIAN_FRONTEND=noninteractive apt-get -y -o Dpkg::Options::="--force-confdef" install   docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
