&"C:/Users/packer_user/hardening/audit.ps1"
&"C:/Users/packer_user/hardening/audit_to_bq.bat"
