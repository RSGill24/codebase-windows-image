Install-Module -Name PowerStig -Scope CurrentUser -Force
